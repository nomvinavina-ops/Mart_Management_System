<?php
declare(strict_types=1);
require_once __DIR__.'/../models/User.php';
require_once __DIR__.'/../validation/UserValidation.php';

final class AuthController {
    public function __construct(private PDO $db) {}
    public function login(array $d): void {
        $errors=UserValidation::validateLogin($d);
        if($errors) jsonResponse(false,'Validation failed.',$errors,422);
        $user=(new User($this->db))->findByLogin(trim($d['login']));
        if(!$user || !password_verify((string)$d['password'],$user['password_hash'])){
            jsonResponse(false,'Invalid username/email or password.',[],401);
        }
        session_regenerate_id(true);
        unset($user['password_hash']);
        $_SESSION['user']=$user;
        jsonResponse(true,'Login successful.',$user);
    }
    public function logout(): void {
        $_SESSION=[];
        if(ini_get('session.use_cookies')){
            $p=session_get_cookie_params();
            setcookie(session_name(),'',['expires'=>time()-42000,'path'=>$p['path'],'domain'=>$p['domain'],'secure'=>$p['secure'],'httponly'=>$p['httponly'],'samesite'=>$p['samesite'] ?? 'Lax']);
        }
        session_destroy();
        jsonResponse(true,'Logged out.');
    }
}
