<?php
declare(strict_types=1);
require_once __DIR__.'/../services/ProductService.php';
require_once __DIR__.'/../validation/ProductValidation.php';

final class ProductController {
    public function __construct(private PDO $db) {}
    public function list(): void { requireLogin(); jsonResponse(true,'',(new ProductService($this->db))->all(trim($_GET['search']??''),(int)($_GET['category_id']??0))); }
    public function create(): void { requireRole(['Admin','Manager']); $d=requestData(); $e=ProductValidation::validate($d); if($e)jsonResponse(false,'Validation failed.',$e,422); try{$id=(new ProductService($this->db))->create($d);jsonResponse(true,'Product created.',['product_id'=>$id],201);}catch(PDOException $x){jsonResponse(false,$x->errorInfo[1]??'Database error.',[],409);} }
    public function update(): void { requireRole(['Admin','Manager']); $id=(int)($_GET['id']??0);$d=requestData();$e=ProductValidation::validate($d);if(!$id)$e['id']='Invalid product id.';if($e)jsonResponse(false,'Validation failed.',$e,422);try{(new ProductService($this->db))->update($id,$d);jsonResponse(true,'Product updated.');}catch(PDOException $x){jsonResponse(false,$x->errorInfo[1]??'Database error.',[],409);} }
    public function delete(): void { requireRole(['Admin','Manager']);$id=(int)($_GET['id']??0);if(!$id)jsonResponse(false,'Invalid product id.',[],422);try{(new ProductService($this->db))->delete($id);jsonResponse(true,'Product deleted.');}catch(PDOException $x){jsonResponse(false,'Product cannot be deleted because it is used by existing transactions.',[],409);}catch(InvalidArgumentException $e){jsonResponse(false,$e->getMessage(),[],404);} }
}
