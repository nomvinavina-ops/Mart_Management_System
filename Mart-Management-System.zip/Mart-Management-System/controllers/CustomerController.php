<?php
declare(strict_types=1);
require_once __DIR__.'/../validation/CustomerValidation.php';
final class CustomerController {
 public function __construct(private PDO $db){}
 public function list():void{requireLogin();$q=trim($_GET['search']??'');$s=$this->db->prepare('SELECT * FROM customers WHERE customer_name LIKE ? OR phone LIKE ? OR email LIKE ? ORDER BY customer_id DESC');$like="%$q%";$s->execute([$like,$like,$like]);jsonResponse(true,'',$s->fetchAll());}
 public function save():void{requireRole(['Admin','Manager']);$d=requestData();$e=CustomerValidation::validate($d);if($e)jsonResponse(false,'Validation failed.',$e,422);$id=(int)($d['customer_id']??0);if($id){$s=$this->db->prepare('UPDATE customers SET customer_name=?,phone=?,email=?,address=?,membership_info=?,loyalty_points=? WHERE customer_id=?');$s->execute([trim($d['customer_name']),trim($d['phone']??''),trim($d['email']??''),trim($d['address']??''),trim($d['membership_info']??''),(int)($d['loyalty_points']??0),$id]);jsonResponse(true,'Customer updated.');}else{$s=$this->db->prepare('INSERT INTO customers(customer_name,phone,email,address,membership_info,loyalty_points) VALUES(?,?,?,?,?,?)');$s->execute([trim($d['customer_name']),trim($d['phone']??''),trim($d['email']??''),trim($d['address']??''),trim($d['membership_info']??''),(int)($d['loyalty_points']??0)]);jsonResponse(true,'Customer created.',['customer_id'=>(int)$this->db->lastInsertId()],201);}}
 public function delete():void{requireRole(['Admin','Manager']);$id=(int)($_GET['id']??0);if(!$id)jsonResponse(false,'Invalid customer id.',[],422);$s=$this->db->prepare('DELETE FROM customers WHERE customer_id=?');$s->execute([$id]);jsonResponse(true,'Customer deleted.');}
}
