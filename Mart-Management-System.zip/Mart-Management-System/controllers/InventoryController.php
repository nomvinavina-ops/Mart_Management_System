<?php
declare(strict_types=1);
require_once __DIR__.'/../services/InventoryService.php';

final class InventoryController {
    public function __construct(private PDO $db) {}
    public function list(): void {
        requireRole(['Admin','Manager','Cashier']);
        jsonResponse(true,'',(new InventoryService($this->db))->all());
    }
}
