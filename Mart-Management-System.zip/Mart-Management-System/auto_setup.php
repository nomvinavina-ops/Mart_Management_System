<?php
declare(strict_types=1);
require_once __DIR__.'/config/database.php';

try {
    $db = (new Database())->getConnection();
    
    // ពិនិត្យថាតារាងមានឬអត់
    $tables = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $requiredTables = ['users', 'products', 'categories', 'suppliers', 
                       'customers', 'sales', 'purchases', 'inventory'];
    $missing = array_diff($requiredTables, $tables);
    
    if (empty($missing)) {
        echo '<h2>✅ Database Ready</h2>';
        echo '<p>Tables found: '.count($tables).'</p>';
        echo '<a href="index.php">Go to Login</a>';
    } else {
        echo '<h2>⚠️ Database Incomplete</h2>';
        echo '<p>Missing tables: '.implode(', ', $missing).'</p>';
        echo '<p>Import <code>database/mart_management.sql</code> via phpMyAdmin.</p>';
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo '<h2>Database setup error</h2><pre>'.htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8').'</pre>';
}
