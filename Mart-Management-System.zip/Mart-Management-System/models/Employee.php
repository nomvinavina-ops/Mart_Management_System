<?php
declare(strict_types=1);

/** Data access class for Employee. Add domain-specific queries here as the module grows. */
final class Employee {
    public function __construct(private PDO $db) {}
}
