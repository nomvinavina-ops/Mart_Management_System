<?php
declare(strict_types=1);

/** Data access class for Product. Add domain-specific queries here as the module grows. */
final class Product {
    public function __construct(private PDO $db) {}
}
