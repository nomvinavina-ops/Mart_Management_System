<?php
declare(strict_types=1);

/** Data access class for Expense. Add domain-specific queries here as the module grows. */
final class Expense {
    public function __construct(private PDO $db) {}
}
