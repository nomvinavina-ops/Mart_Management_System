<?php
declare(strict_types=1);

final class User {
    public function __construct(private PDO $db) {}

    public function findByLogin(string $login): ?array {
        $stmt = $this->db->prepare(
            'SELECT u.user_id, u.username, u.email, u.password_hash, r.role_name
             FROM users u JOIN roles r ON r.role_id = u.role_id
             WHERE u.username = :login OR u.email = :login LIMIT 1'
        );
        $stmt->execute(['login'=>$login]);
        $row = $stmt->fetch();
        return $row ?: null;
    }
}
