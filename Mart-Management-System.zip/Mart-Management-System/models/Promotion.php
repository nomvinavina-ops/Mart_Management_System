<?php
declare(strict_types=1);

/** Data access class for Promotion. Add domain-specific queries here as the module grows. */
final class Promotion {
    public function __construct(private PDO $db) {}
}
