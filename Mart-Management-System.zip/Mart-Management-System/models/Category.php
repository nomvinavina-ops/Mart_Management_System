<?php
declare(strict_types=1);

/** Data access class for Category. Add domain-specific queries here as the module grows. */
final class Category {
    public function __construct(private PDO $db) {}
}
