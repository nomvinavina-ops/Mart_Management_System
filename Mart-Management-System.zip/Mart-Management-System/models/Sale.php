<?php
declare(strict_types=1);

/** Data access class for Sale. Add domain-specific queries here as the module grows. */
final class Sale {
    public function __construct(private PDO $db) {}
}
