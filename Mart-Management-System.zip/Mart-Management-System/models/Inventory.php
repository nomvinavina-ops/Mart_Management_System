<?php
declare(strict_types=1);

/** Data access class for Inventory. Add domain-specific queries here as the module grows. */
final class Inventory {
    public function __construct(private PDO $db) {}
}
