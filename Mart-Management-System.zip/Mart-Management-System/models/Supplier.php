<?php
declare(strict_types=1);

/** Data access class for Supplier. Add domain-specific queries here as the module grows. */
final class Supplier {
    public function __construct(private PDO $db) {}
}
