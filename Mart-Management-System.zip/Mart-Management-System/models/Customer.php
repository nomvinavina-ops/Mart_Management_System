<?php
declare(strict_types=1);

/** Data access class for Customer. Add domain-specific queries here as the module grows. */
final class Customer {
    public function __construct(private PDO $db) {}
}
