<?php
declare(strict_types=1);

/** Data access class for Role. Add domain-specific queries here as the module grows. */
final class Role {
    public function __construct(private PDO $db) {}
}
