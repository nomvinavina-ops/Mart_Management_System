<?php
// បន្ថែមនៅដើម index.php និងរាល់ API
session_start([
    'cookie_httponly' => true,
    'cookie_secure'   => false, // true ប្រសិនបើប្រើ HTTPS
    'use_strict_mode' => true,
]);
session_start();
if (!empty($_SESSION['user'])) {
    header('Location: views/dashboard.html');
} else {
    header('Location: views/login.html');
}
exit;
