<?php
declare(strict_types=1);

/**
 * ចាប់ផ្តើម Session ដោយសុវត្ថិភាពខ្ពស់
 */
function secure_session_start(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;

    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => isset($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Strict'
    ]);

    session_start();

    // Regenerate ID រៀងរាល់ ៣០ នាទី
    if (!isset($_SESSION['last_regeneration'])) {
        session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    } elseif (time() - $_SESSION['last_regeneration'] > 1800) {
        session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    }

    // ពិនិត្យ Session Hijacking (User-Agent + IP)
    $fingerprint = hash('sha256', ($_SERVER['HTTP_USER_AGENT'] ?? '') . ($_SERVER['REMOTE_ADDR'] ?? ''));
    if (!isset($_SESSION['fingerprint'])) {
        $_SESSION['fingerprint'] = $fingerprint;
    } elseif (!hash_equals($_SESSION['fingerprint'], $fingerprint)) {
        session_unset();
        session_destroy();
        http_response_code(403);
        exit(json_encode(['success' => false, 'message' => 'Session security breach detected']));
    }
}

/**
 * បង្កើត CSRF Token
 */
function generate_csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = time();
    }
    return $_SESSION['csrf_token'];
}

/**
 * ពិនិត្យ CSRF Token សម្រាប់ Request ទាំងអស់ដែលមិនមែន GET
 */
function verify_csrf_token(): void {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if ($method === 'GET' || $method === 'HEAD') return;

    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? $_POST['csrf_token'] ?? '';
    $sessionToken = $_SESSION['csrf_token'] ?? '';

    if (!$sessionToken || !hash_equals($sessionToken, $token)) {
        http_response_code(403);
        exit(json_encode(['success' => false, 'message' => 'Invalid CSRF token']));
    }

    // Token មានអាយុកាល ២ ម៉ោង
    if (isset($_SESSION['csrf_token_time']) && (time() - $_SESSION['csrf_token_time'] > 7200)) {
        unset($_SESSION['csrf_token'], $_SESSION['csrf_token_time']);
        http_response_code(403);
        exit(json_encode(['success' => false, 'message' => 'CSRF token expired']));
    }
}

/**
 * Rate Limiting: ពិនិត្យចំនួនការព្យាយាម Login
 */
function check_rate_limit(PDO $db, string $ip, int $maxAttempts = 5, int $windowMinutes = 15): void {
    $stmt = $db->prepare("
        SELECT COUNT(*) FROM login_attempts 
        WHERE ip_address = ? AND attempted_at > DATE_SUB(NOW(), INTERVAL ? MINUTE)
    ");
    $stmt->execute([$ip, $windowMinutes]);
    $attempts = (int)$stmt->fetchColumn();

    if ($attempts >= $maxAttempts) {
        http_response_code(429);
        echo json_encode([
            'success' => false,
            'message' => "Too many login attempts. Please try again after {$windowMinutes} minutes."
        ]);
        exit;
    }
}

/**
 * កត់ត្រាការព្យាយាម Login បរាជ័យ
 */
function log_failed_attempt(PDO $db, string $ip, string $username): void {
    $stmt = $db->prepare("INSERT INTO login_attempts (ip_address, username) VALUES (?, ?)");
    $stmt->execute([$ip, $username]);
}

/**
 * សម្អាតការព្យាយាមចាស់ៗ (ច្រើនជាង ១ ថ្ងៃ)
 */
function cleanup_old_attempts(PDO $db): void {
    $db->exec("DELETE FROM login_attempts WHERE attempted_at < DATE_SUB(NOW(), INTERVAL 1 DAY)");
}

/**
 * ការពារ XSS
 */
function sanitize(string $input): string {
    return htmlspecialchars(trim($input), ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

/**
 * ពិនិត្យ Role របស់ User
 */
function require_role(array $roles): void {
    if (empty($_SESSION['user']) || !in_array($_SESSION['user']['role'], $roles)) {
        http_response_code(403);
        exit(json_encode(['success' => false, 'message' => 'Permission denied']));
    }
}

/**
 * ពិនិត្យថា User បាន Login ឬអត់
 */
function require_login(): void {
    if (empty($_SESSION['user'])) {
        http_response_code(401);
        exit(json_encode(['success' => false, 'message' => 'Unauthorized']));
    }
}