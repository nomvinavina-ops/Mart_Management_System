<?php
declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '1');

class Database {
    private $host = 'localhost';
    private $port = '3306';
    private $db_name = 'mart';              // ← កែឈ្មោះនៅទីនេះ!
    private $username = 'root';
    private $password = '';                  // ← បើ WampServer មាន Password សូមបញ្ចូល
    public $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            $dsn = "mysql:host={$this->host};port={$this->port};dbname={$this->db_name};charset=utf8mb4";
            $this->conn = new PDO($dsn, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            die("DB Connection Error: " . $e->getMessage());
        }
        return $this->conn;
    }
}
?>