<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    session_start();
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

require_once __DIR__ . '/database.php';

try {
    $pdo = (new Database())->getConnection();
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success'=>false,'message'=>$e->getMessage(),'data'=>[]], JSON_UNESCAPED_UNICODE);
    exit;
}

function jsonResponse(bool $success, string $message = '', array $data = [], int $status = 200): never {
    http_response_code($status);
    echo json_encode(['success'=>$success,'message'=>$message,'data'=>$data], JSON_UNESCAPED_UNICODE);
    exit;
}

function requestData(): array {
    $raw = file_get_contents('php://input');
    if ($raw !== false && trim($raw) !== '') {
        $json = json_decode($raw, true);
        if (is_array($json)) return $json;
    }
    return is_array($_POST) ? $_POST : [];
}

function requireLogin(): array {
    if (empty($_SESSION['user']) || !is_array($_SESSION['user'])) {
        jsonResponse(false, 'Authentication required.', [], 401);
    }
    return $_SESSION['user'];
}

function requireRole(array $roles): array {
    $user = requireLogin();
    if (!in_array($user['role_name'] ?? '', $roles, true)) {
        jsonResponse(false, 'You do not have permission for this action.', [], 403);
    }
    return $user;
}
