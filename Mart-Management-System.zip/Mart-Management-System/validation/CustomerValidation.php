<?php
declare(strict_types=1);
final class CustomerValidation{public static function validate(array $d):array{$e=[];if(trim((string)($d['customer_name']??''))==='')$e['customer_name']='Customer name is required.';if(!empty($d['email'])&&!filter_var($d['email'],FILTER_VALIDATE_EMAIL))$e['email']='Invalid email address.';if(!empty($d['phone'])&&!preg_match('/^[0-9+\-\s]{8,20}$/',$d['phone']))$e['phone']='Invalid phone number.';return $e;}}
