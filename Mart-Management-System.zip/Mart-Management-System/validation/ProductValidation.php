<?php
declare(strict_types=1);
final class ProductValidation {
    public static function validate(array $d): array {
        $e=[];
        if(trim((string)($d['product_code']??''))==='')$e['product_code']='Product code is required.';
        if(trim((string)($d['product_name']??''))==='')$e['product_name']='Product name is required.';
        if(!is_numeric($d['cost_price']??null)||(float)$d['cost_price']<0)$e['cost_price']='Cost price must be a non-negative number.';
        if(!is_numeric($d['selling_price']??null)||(float)$d['selling_price']<0)$e['selling_price']='Selling price must be a non-negative number.';
        if(isset($d['stock'])&&(!is_numeric($d['stock'])||(int)$d['stock']<0))$e['stock']='Stock must be 0 or greater.';
        if(!empty($d['expiry_date'])&&strtotime($d['expiry_date'])===false)$e['expiry_date']='Invalid expiry date.';
        return $e;
    }
}
