<?php
declare(strict_types=1);

final class UserValidation {
    public static function validateLogin(array $d): array {
        $errors=[];
        if (trim((string)($d['login'] ?? ''))==='') $errors['login']='Username or email is required.';
        if (strlen((string)($d['password'] ?? '')) < 1) $errors['password']='Password is required.';
        return $errors;
    }
}
