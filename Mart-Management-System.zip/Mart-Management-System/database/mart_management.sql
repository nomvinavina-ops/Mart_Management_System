CREATE DATABASE IF NOT EXISTS mart_management;
USE mart_management;

-- 1. Users Table (សម្រាប់ Login)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'manager', 'cashier') DEFAULT 'cashier',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert Demo User (Password: password)
INSERT INTO users (username, password, role) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- 2. Categories Table
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);
INSERT INTO categories (name) VALUES ('Drinks'), ('Snacks'), ('Food'), ('Others');

-- 3. Products Table (សម្រាប់ POS និង Inventory)
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(150) NOT NULL,
    category_id INT,
    cost_price DECIMAL(10,2) NOT NULL,
    selling_price DECIMAL(10,2) NOT NULL,
    stock_qty INT DEFAULT 0,
    image VARCHAR(255) DEFAULT 'default.png',
    status ENUM('Available', 'Unavailable') DEFAULT 'Available',
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- Insert Demo Products (ដូចក្នុងរូបភាព POS)
INSERT INTO products (code, name, category_id, cost_price, selling_price, stock_qty, image) VALUES
('P001', 'Coca Cola', 1, 0.50, 1.00, 50, 'coke.png'),
('P002', 'Lays Chips', 2, 0.60, 1.00, 5, 'lays.png'),
('P003', 'Water', 1, 0.20, 0.50, 100, 'water.png'),
('P004', 'Instant Noodles', 3, 0.80, 1.25, 30, 'noodles.png');

-- 4. Sales Table (សម្រាប់ POS Checkout)
CREATE TABLE sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_no VARCHAR(50) UNIQUE NOT NULL,
    user_id INT,
    total_amount DECIMAL(10,2) NOT NULL,
    tax_amount DECIMAL(10,2) DEFAULT 0,
    discount_amount DECIMAL(10,2) DEFAULT 0,
    payment_method VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- 5. Sale Items Table
CREATE TABLE sale_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sale_id INT,
    product_id INT,
    qty INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (sale_id) REFERENCES sales(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);