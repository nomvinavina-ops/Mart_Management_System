USE mart_management;

-- ============ PURCHASE ORDERS ============
CREATE TABLE IF NOT EXISTS purchase_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    po_number VARCHAR(50) UNIQUE NOT NULL,
    supplier_id INT NOT NULL,
    order_date DATE NOT NULL,
    expected_date DATE,
    status ENUM('Pending', 'Received', 'Cancelled', 'Partial') DEFAULT 'Pending',
    subtotal DECIMAL(12,2) DEFAULT 0,
    tax DECIMAL(12,2) DEFAULT 0,
    total DECIMAL(12,2) DEFAULT 0,
    notes TEXT,
    created_by INT,
    received_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id),
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_status (status),
    INDEX idx_supplier (supplier_id)
);

CREATE TABLE IF NOT EXISTS purchase_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    po_id INT NOT NULL,
    product_id INT NOT NULL,
    qty INT NOT NULL,
    cost_price DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(12,2) NOT NULL,
    received_qty INT DEFAULT 0,
    FOREIGN KEY (po_id) REFERENCES purchase_orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- ============ PROMOTIONS ============
CREATE TABLE IF NOT EXISTS promotions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    type ENUM('PERCENT', 'AMOUNT', 'BOGO') NOT NULL,
    value DECIMAL(10,2) DEFAULT 0,
    product_id INT NULL,          -- NULL = Apply to all
    category_id INT NULL,
    buy_qty INT DEFAULT 0,        -- សម្រាប់ BOGO
    get_qty INT DEFAULT 0,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status ENUM('Active', 'Inactive') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    INDEX idx_dates (start_date, end_date)
);

-- ============ NOTIFICATIONS ============
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,             -- NULL = For all users
    type ENUM('LOW_STOCK', 'OUT_OF_STOCK', 'EXPIRY', 'NEW_PURCHASE', 'DAILY_SALES', 'SYSTEM') NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT,
    reference_id INT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_read (user_id, is_read)
);

-- ============ STORE SETTINGS ============
CREATE TABLE IF NOT EXISTS store_settings (
    id INT PRIMARY KEY DEFAULT 1,
    store_name VARCHAR(150) DEFAULT 'Mart Management System',
    store_address TEXT,
    store_phone VARCHAR(30),
    store_email VARCHAR(150),
    currency VARCHAR(10) DEFAULT 'USD',
    currency_symbol VARCHAR(5) DEFAULT '$',
    tax_rate DECIMAL(5,2) DEFAULT 10.00,
    logo VARCHAR(255) DEFAULT 'logo.png',
    receipt_footer TEXT,
    low_stock_threshold INT DEFAULT 5,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT IGNORE INTO store_settings (id, store_name) VALUES (1, 'Mart Management System');

-- ============ PRODUCT EXPIRY (បន្ថែម) ============
ALTER TABLE products 
    ADD COLUMN IF NOT EXISTS expiry_date DATE NULL AFTER stock_qty,
    ADD COLUMN IF NOT EXISTS batch_no VARCHAR(50) NULL;