# Mart Management System — WampServer Build

PHP 8+ / MySQL or MariaDB / HTML / CSS / JavaScript Fetch API / PDO.

## WampServer configuration

This ZIP is preconfigured for the common WampServer local setup:

- Web root: `C:\wamp64\www\`
- URL: `http://localhost/Mart-Management-System/`
- Database host: `localhost`
- Database port: `3306`
- Database name: `mart_management`
- Database user: `root`
- Database password: empty by default

If your WampServer root account has a password, edit `config/database.php` and set `$this->password`. If your MySQL/MariaDB port is not 3306, change `$this->port`.

## Installation

1. Extract this folder into:
   `C:\wamp64\www\Mart-Management-System\`
2. Start WampServer and wait until the Wamp icon is **green**.
3. Make sure Apache and MySQL/MariaDB are running.
4. Open phpMyAdmin:
   `http://localhost/phpmyadmin/`
5. Import:
   `database/mart_management.sql`
6. Open:
   `http://localhost/Mart-Management-System/`

### Important database warning

The SQL file is a clean-install script and starts with `DROP DATABASE IF EXISTS mart_management`. Back up an existing database before importing if you need to keep its data.

## Demo accounts

- `admin` / `password`
- `manager` / `password`
- `cashier` / `password`

Change demo passwords before real use.

## Troubleshooting

### Error: could not find driver
Enable `pdo_mysql` in WampServer's PHP extensions, then restart WampServer.

### Error: connection refused
Check the MySQL/MariaDB port in WampServer. This build expects **3306**.

### Access denied for user root
Your WampServer root account likely has a password. Set it in `config/database.php`.

### 404 for the project
Confirm the folder is exactly:
`C:\wamp64\www\Mart-Management-System\`

Then use:
`http://localhost/Mart-Management-System/`

## Main APIs

- POST `api/auth/login.php`
- POST `api/auth/logout.php`
- GET `api/auth/me.php`
- GET/POST/PUT/DELETE `api/products/index.php`
- GET `api/categories/index.php`
- GET `api/dashboard/summary.php`
- POST `api/pos/sale.php`
- GET `api/inventory/index.php`
- POST `api/purchases/create.php`
- GET/POST/PUT/DELETE `api/customers/index.php`
- GET/POST/PUT/DELETE `api/suppliers/index.php`
- GET `api/reports/summary.php`

## Validation

PHP files should pass `php -l`; JavaScript files should pass `node --check`.
