<?php
session_start();
header("Content-Type: application/json");
require_once '../../config/database.php';

if (empty($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "Unauthorized"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"));
$cart = $data->cart ?? [];
$taxRate = 0.10; // 10% Tax

if (empty($cart)) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Cart is empty"]);
    exit;
}

$db = (new Database())->getConnection();
try {
    $db->beginTransaction();
    
    $subtotal = 0;
    foreach ($cart as $item) {
        $subtotal += $item->price * $item->qty;
    }
    $tax = $subtotal * $taxRate;
    $total = $subtotal + $tax;
    $invoice_no = "INV-" . date("Ymd") . "-" . rand(1000, 9999);

    // Insert Sale
    $stmt = $db->prepare("INSERT INTO sales (invoice_no, user_id, total_amount, tax_amount, payment_method) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$invoice_no, $_SESSION['user']['id'], $total, $tax, "Cash"]);
    $sale_id = $db->lastInsertId();

    // Insert Sale Items & Update Stock
    foreach ($cart as $item) {
        $stmt = $db->prepare("INSERT INTO sale_items (sale_id, product_id, qty, price, subtotal) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$sale_id, $item->id, $item->qty, $item->price, $item->price * $item->qty]);

        $stmt = $db->prepare("UPDATE products SET stock_qty = stock_qty - ? WHERE id = ?");
        $stmt->execute([$item->qty, $item->id]);
    }

    $db->commit();
    echo json_encode(["success" => true, "invoice" => $invoice_no, "total" => $total]);
} catch (Exception $e) {
    $db->rollBack();
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Checkout failed: " . $e->getMessage()]);
}
?>