<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();
require_role(['admin', 'manager']);
verify_csrf_token();

$db = (new Database())->getConnection();
$data = json_decode(file_get_contents("php://input"), true);
$po_id = (int)($data['po_id'] ?? 0);

if (!$po_id) {
    http_response_code(400);
    exit(json_encode(['success' => false, 'message' => 'PO ID required']));
}

try {
    $db->beginTransaction();

    // ពិនិត្យ PO
    $stmt = $db->prepare("SELECT * FROM purchase_orders WHERE id = ? AND status = 'Pending' FOR UPDATE");
    $stmt->execute([$po_id]);
    $po = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$po) {
        throw new RuntimeException('PO not found or already received');
    }

    // ទាញ Items
    $stmt = $db->prepare("SELECT * FROM purchase_items WHERE po_id = ?");
    $stmt->execute([$po_id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Update Stock និង Log សម្រាប់ Item នីមួយៗ
    foreach ($items as $item) {
        // Stock បច្ចុប្បន្ន
        $stmt = $db->prepare("SELECT stock_qty FROM products WHERE id = ? FOR UPDATE");
        $stmt->execute([$item['product_id']]);
        $before = (int)$stmt->fetchColumn();
        $after = $before + (int)$item['qty'];

        // Update product stock + cost_price (ទាមទារបើចង់ Update)
        $stmt = $db->prepare("UPDATE products SET stock_qty = ?, cost_price = ? WHERE id = ?");
        $stmt->execute([$after, $item['cost_price'], $item['product_id']]);

        // Log
        $stmt = $db->prepare("INSERT INTO inventory_logs 
            (product_id, type, quantity, before_qty, after_qty, reason, reference, user_id) 
            VALUES (?, 'IN', ?, ?, ?, 'Purchase Order', ?, ?)");
        $stmt->execute([
            $item['product_id'],
            $item['qty'],
            $before,
            $after,
            $po['po_number'],
            $_SESSION['user']['id']
        ]);

        // Update received_qty
        $stmt = $db->prepare("UPDATE purchase_items SET received_qty = ? WHERE id = ?");
        $stmt->execute([$item['qty'], $item['id']]);
    }

    // Update PO Status
    $stmt = $db->prepare("UPDATE purchase_orders SET status = 'Received', received_at = NOW() WHERE id = ?");
    $stmt->execute([$po_id]);

    $db->commit();
    echo json_encode(['success' => true, 'message' => 'Stock received successfully']);
} catch (Throwable $e) {
    $db->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}