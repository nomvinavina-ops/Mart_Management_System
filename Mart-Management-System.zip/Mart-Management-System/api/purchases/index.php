<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();
verify_csrf_token();

$db = (new Database())->getConnection();
$method = $_SERVER['REQUEST_METHOD'];

// ---------- GET: List Purchase Orders ----------
if ($method === 'GET') {
    $status = $_GET['status'] ?? 'all';
    $sql = "SELECT po.*, s.company_name AS supplier_name, u.username AS created_by_name 
            FROM purchase_orders po 
            JOIN suppliers s ON po.supplier_id = s.id 
            LEFT JOIN users u ON po.created_by = u.id 
            WHERE 1=1";
    $params = [];

    if ($status !== 'all') {
        $sql .= " AND po.status = ?";
        $params[] = $status;
    }
    $sql .= " ORDER BY po.id DESC LIMIT 100";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // ទាញ Items សម្រាប់ PO នីមួយៗ
    foreach ($orders as &$po) {
        $stmt = $db->prepare("SELECT pi.*, p.name AS product_name, p.code 
            FROM purchase_items pi 
            JOIN products p ON pi.product_id = p.id 
            WHERE pi.po_id = ?");
        $stmt->execute([$po['id']]);
        $po['items'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    echo json_encode(['success' => true, 'data' => $orders]);
    exit;
}

// ---------- POST: Create PO ----------
if ($method === 'POST') {
    require_role(['admin', 'manager']);
    $data = json_decode(file_get_contents("php://input"), true);

    // Validation
    $errors = [];
    if (empty($data['supplier_id'])) $errors[] = "Supplier is required";
    if (empty($data['items']) || !is_array($data['items'])) $errors[] = "At least 1 item required";

    if ($errors) {
        http_response_code(422);
        exit(json_encode(['success' => false, 'errors' => $errors]));
    }

    try {
        $db->beginTransaction();

        $po_number = 'PO-' . date('Ymd') . '-' . str_pad((string)random_int(1, 9999), 4, '0', STR_PAD_LEFT);
        $subtotal = 0;
        foreach ($data['items'] as $item) {
            $subtotal += (float)$item['cost_price'] * (int)$item['qty'];
        }
        $taxRate = (float)($data['tax_rate'] ?? 0);
        $tax = $subtotal * ($taxRate / 100);
        $total = $subtotal + $tax;

        // Insert PO
        $stmt = $db->prepare("INSERT INTO purchase_orders 
            (po_number, supplier_id, order_date, expected_date, subtotal, tax, total, notes, created_by) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $po_number,
            (int)$data['supplier_id'],
            $data['order_date'] ?? date('Y-m-d'),
            $data['expected_date'] ?? null,
            $subtotal,
            $tax,
            $total,
            sanitize($data['notes'] ?? ''),
            $_SESSION['user']['id']
        ]);
        $po_id = (int)$db->lastInsertId();

        // Insert Items
        $stmt = $db->prepare("INSERT INTO purchase_items 
            (po_id, product_id, qty, cost_price, subtotal) VALUES (?, ?, ?, ?, ?)");
        foreach ($data['items'] as $item) {
            $stmt->execute([
                $po_id,
                (int)$item['product_id'],
                (int)$item['qty'],
                (float)$item['cost_price'],
                (float)$item['cost_price'] * (int)$item['qty']
            ]);
        }

        // Notification
        $stmt = $db->prepare("INSERT INTO notifications (type, title, message, reference_id) 
            VALUES ('NEW_PURCHASE', ?, ?, ?)");
        $stmt->execute([
            "New Purchase Order: $po_number",
            "Purchase order created for supplier ID " . $data['supplier_id'],
            $po_id
        ]);

        $db->commit();
        echo json_encode(['success' => true, 'po_id' => $po_id, 'po_number' => $po_number]);
    } catch (Throwable $e) {
        $db->rollBack();
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}