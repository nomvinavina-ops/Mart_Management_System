<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();
require_role(['admin', 'manager']);
verify_csrf_token();

$db = (new Database())->getConnection();
$data = json_decode(file_get_contents("php://input"), true);
$po_id = (int)($data['po_id'] ?? 0);

if (!$po_id) exit(json_encode(['success' => false, 'message' => 'PO ID required']));

$stmt = $db->prepare("UPDATE purchase_orders SET status = 'Cancelled' WHERE id = ? AND status = 'Pending'");
$stmt->execute([$po_id]);

echo json_encode(['success' => true, 'message' => 'Purchase order cancelled']);