<?php
session_start();
header("Content-Type: application/json; charset=UTF-8");
require_once '../../config/database.php';

if (empty($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "Unauthorized"]);
    exit;
}

$db = (new Database())->getConnection();

// ---- Summary Cards ----
$totalProducts = $db->query("SELECT COUNT(*) FROM products")->fetchColumn();
$totalCategories = $db->query("SELECT COUNT(*) FROM categories")->fetchColumn();
$totalCustomers = $db->query("SELECT COUNT(*) FROM customers")->fetchColumn() ?? 0;
$totalSuppliers = $db->query("SELECT COUNT(*) FROM suppliers")->fetchColumn() ?? 0;

$todaySales = $db->query("SELECT COALESCE(SUM(total_amount),0) FROM sales WHERE DATE(created_at) = CURDATE()")->fetchColumn();
$monthlyRevenue = $db->query("SELECT COALESCE(SUM(total_amount),0) FROM sales WHERE MONTH(created_at)=MONTH(CURDATE()) AND YEAR(created_at)=YEAR(CURDATE())")->fetchColumn();

// ---- Low Stock Alert ----
$lowStock = $db->query("SELECT name, stock_qty FROM products WHERE stock_qty <= 5 ORDER BY stock_qty ASC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

// ---- Best Selling Products ----
$bestSellers = $db->query("
    SELECT p.name, SUM(si.qty) AS sold, SUM(si.subtotal) AS total 
    FROM sale_items si 
    JOIN products p ON si.product_id = p.id 
    GROUP BY p.id 
    ORDER BY sold DESC 
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// ---- Monthly Sales Chart (12 ខែ) ----
$monthlyChart = $db->query("
    SELECT DATE_FORMAT(created_at, '%b') AS month, SUM(total_amount) AS total 
    FROM sales 
    WHERE YEAR(created_at) = YEAR(CURDATE()) 
    GROUP BY MONTH(created_at) 
    ORDER BY MONTH(created_at)
")->fetchAll(PDO::FETCH_ASSOC);

// បើគ្មានទិន្នន័យ បង្កើត Array ទទេ
$months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
$chartData = array_fill_keys($months, 0);
foreach ($monthlyChart as $row) {
    $chartData[$row['month']] = (float)$row['total'];
}

echo json_encode([
    "success" => true,
    "summary" => [
        "total_products" => (int)$totalProducts,
        "total_categories" => (int)$totalCategories,
        "total_customers" => (int)$totalCustomers,
        "total_suppliers" => (int)$totalSuppliers,
        "today_sales" => (float)$todaySales,
        "monthly_revenue" => (float)$monthlyRevenue,
    ],
    "low_stock" => $lowStock,
    "best_sellers" => $bestSellers,
    "chart" => [
        "labels" => array_keys($chartData),
        "data" => array_values($chartData)
    ]
]);