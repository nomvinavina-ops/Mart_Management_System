<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();
require_role(['admin', 'manager']);
verify_csrf_token();

$db = (new Database())->getConnection();
$data = json_decode(file_get_contents("php://input"), true);
$id = (int)($data['id'] ?? 0);

if (!$id) exit(json_encode(['success' => false, 'message' => 'ID required']));

$stmt = $db->prepare("UPDATE promotions SET 
    name = ?, type = ?, value = ?, product_id = ?, category_id = ?, 
    buy_qty = ?, get_qty = ?, start_date = ?, end_date = ?, status = ?
    WHERE id = ?");
$stmt->execute([
    sanitize($data['name']),
    $data['type'],
    (float)($data['value'] ?? 0),
    !empty($data['product_id']) ? (int)$data['product_id'] : null,
    !empty($data['category_id']) ? (int)$data['category_id'] : null,
    (int)($data['buy_qty'] ?? 0),
    (int)($data['get_qty'] ?? 0),
    $data['start_date'],
    $data['end_date'],
    $data['status'] ?? 'Active',
    $id
]);
echo json_encode(['success' => true]);