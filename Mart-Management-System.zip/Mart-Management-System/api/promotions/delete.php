<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();
require_role(['admin']);
verify_csrf_token();

$db = (new Database())->getConnection();
$data = json_decode(file_get_contents("php://input"), true);
$stmt = $db->prepare("DELETE FROM promotions WHERE id = ?");
$stmt->execute([(int)($data['id'] ?? 0)]);
echo json_encode(['success' => true]);