<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();
verify_csrf_token();

$db = (new Database())->getConnection();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // Auto-update expired promotions
    $db->exec("UPDATE promotions SET status = 'Inactive' WHERE end_date < CURDATE() AND status = 'Active'");

    $stmt = $db->query("SELECT pr.*, p.name AS product_name, c.name AS category_name 
        FROM promotions pr 
        LEFT JOIN products p ON pr.product_id = p.id 
        LEFT JOIN categories c ON pr.category_id = c.id 
        ORDER BY pr.id DESC");
    echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    exit;
}

if ($method === 'POST') {
    require_role(['admin', 'manager']);
    $data = json_decode(file_get_contents("php://input"), true);

    $errors = [];
    if (empty($data['name'])) $errors[] = "Promotion name required";
    if (empty($data['type'])) $errors[] = "Type required";
    if (empty($data['start_date']) || empty($data['end_date'])) $errors[] = "Start/End date required";
    if ($data['start_date'] > $data['end_date']) $errors[] = "Start date must be before end date";
    if (in_array($data['type'], ['PERCENT', 'AMOUNT']) && empty($data['value'])) $errors[] = "Value required";
    if ($data['type'] === 'BOGO' && (empty($data['buy_qty']) || empty($data['get_qty']))) $errors[] = "Buy/Get qty required for BOGO";

    if ($errors) {
        http_response_code(422);
        exit(json_encode(['success' => false, 'errors' => $errors]));
    }

    $stmt = $db->prepare("INSERT INTO promotions 
        (name, type, value, product_id, category_id, buy_qty, get_qty, start_date, end_date, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        sanitize($data['name']),
        $data['type'],
        (float)($data['value'] ?? 0),
        !empty($data['product_id']) ? (int)$data['product_id'] : null,
        !empty($data['category_id']) ? (int)$data['category_id'] : null,
        (int)($data['buy_qty'] ?? 0),
        (int)($data['get_qty'] ?? 0),
        $data['start_date'],
        $data['end_date'],
        $data['status'] ?? 'Active'
    ]);
    echo json_encode(['success' => true, 'id' => $db->lastInsertId()]);
}