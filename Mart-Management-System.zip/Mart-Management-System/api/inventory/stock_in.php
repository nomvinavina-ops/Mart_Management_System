<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();
verify_csrf_token();

$db = (new Database())->getConnection();
$data = json_decode(file_get_contents("php://input"), true);

$productId = (int)($data['product_id'] ?? 0);
$qty       = (int)($data['quantity'] ?? 0);
$reason    = sanitize($data['reason'] ?? 'Purchase');
$reference = sanitize($data['reference'] ?? '');

if (!$productId || $qty <= 0) {
    http_response_code(422);
    exit(json_encode(['success' => false, 'message' => 'Invalid product or quantity']));
}

try {
    $db->beginTransaction();

    // ទាញ Stock បច្ចុប្បន្ន
    $stmt = $db->prepare("SELECT stock_qty FROM products WHERE id = ? FOR UPDATE");
    $stmt->execute([$productId]);
    $before = (int)$stmt->fetchColumn();

    if ($before === false) {
        throw new RuntimeException('Product not found');
    }

    $after = $before + $qty;

    // Update Stock
    $stmt = $db->prepare("UPDATE products SET stock_qty = ? WHERE id = ?");
    $stmt->execute([$after, $productId]);

    // Log
    $stmt = $db->prepare("INSERT INTO inventory_logs 
        (product_id, type, quantity, before_qty, after_qty, reason, reference, user_id) 
        VALUES (?, 'IN', ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $productId, $qty, $before, $after, $reason, $reference, $_SESSION['user']['id']
    ]);

    $db->commit();
    echo json_encode(['success' => true, 'new_qty' => $after, 'message' => 'Stock added successfully']);
} catch (Throwable $e) {
    $db->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}