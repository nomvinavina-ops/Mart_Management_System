<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();
verify_csrf_token();

$db = (new Database())->getConnection();
$data = json_decode(file_get_contents("php://input"), true);

$productId = (int)($data['product_id'] ?? 0);
$qty       = (int)($data['quantity'] ?? 0);
$reason    = sanitize($data['reason'] ?? 'Damage/Loss');

if (!$productId || $qty <= 0) {
    http_response_code(422);
    exit(json_encode(['success' => false, 'message' => 'Invalid parameters']));
}

try {
    $db->beginTransaction();

    $stmt = $db->prepare("SELECT stock_qty FROM products WHERE id = ? FOR UPDATE");
    $stmt->execute([$productId]);
    $before = (int)$stmt->fetchColumn();

    if ($before < $qty) {
        throw new RuntimeException("Insufficient stock. Available: $before");
    }

    $after = $before - $qty;

    $stmt = $db->prepare("UPDATE products SET stock_qty = ? WHERE id = ?");
    $stmt->execute([$after, $productId]);

    $stmt = $db->prepare("INSERT INTO inventory_logs 
        (product_id, type, quantity, before_qty, after_qty, reason, user_id) 
        VALUES (?, 'OUT', ?, ?, ?, ?, ?)");
    $stmt->execute([$productId, $qty, $before, $after, $reason, $_SESSION['user']['id']]);

    $db->commit();
    echo json_encode(['success' => true, 'new_qty' => $after]);
} catch (Throwable $e) {
    $db->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}