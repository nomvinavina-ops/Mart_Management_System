<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();

$db = (new Database())->getConnection();

$productId = (int)($_GET['product_id'] ?? 0);
$limit = min((int)($_GET['limit'] ?? 50), 200);

$sql = "SELECT l.*, p.name AS product_name, p.code AS product_code, u.username 
        FROM inventory_logs l 
        JOIN products p ON l.product_id = p.id 
        LEFT JOIN users u ON l.user_id = u.id 
        WHERE 1=1";
$params = [];

if ($productId > 0) {
    $sql .= " AND l.product_id = ?";
    $params[] = $productId;
}

$sql .= " ORDER BY l.created_at DESC LIMIT $limit";

$stmt = $db->prepare($sql);
$stmt->execute($params);
echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);