<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();

$db = (new Database())->getConnection();

$search = $_GET['search'] ?? '';
$filter = $_GET['filter'] ?? 'all'; // all | low | out

$sql = "SELECT p.id, p.code, p.name, p.stock_qty, p.selling_price, 
        c.name AS category, p.status
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id 
        WHERE 1=1";
$params = [];

if ($search !== '') {
    $sql .= " AND (p.name LIKE ? OR p.code LIKE ?)";
    $params = ["%$search%", "%$search%"];
}

if ($filter === 'low') {
    $sql .= " AND p.stock_qty > 0 AND p.stock_qty <= 5";
} elseif ($filter === 'out') {
    $sql .= " AND p.stock_qty = 0";
}

$sql .= " ORDER BY p.stock_qty ASC, p.name ASC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// សង្ខេប
$summary = [
    'total_items' => count($items),
    'total_stock_value' => array_sum(array_map(fn($i) => $i['stock_qty'] * $i['selling_price'], $items)),
    'low_stock_count' => count(array_filter($items, fn($i) => $i['stock_qty'] > 0 && $i['stock_qty'] <= 5)),
    'out_of_stock_count' => count(array_filter($items, fn($i) => $i['stock_qty'] == 0))
];

echo json_encode(['success' => true, 'data' => $items, 'summary' => $summary]);