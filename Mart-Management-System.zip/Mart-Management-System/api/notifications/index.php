<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();

$db = (new Database())->getConnection();

// បង្កើត Notifications ស្វ័យប្រវត្តិ (Low Stock + Out of Stock)
$lowStockThreshold = (int)$db->query("SELECT low_stock_threshold FROM store_settings WHERE id=1")->fetchColumn() ?: 5;

$lowStock = $db->query("SELECT id, name, stock_qty FROM products WHERE stock_qty > 0 AND stock_qty <= $lowStockThreshold")->fetchAll(PDO::FETCH_ASSOC);
$outStock = $db->query("SELECT id, name FROM products WHERE stock_qty = 0")->fetchAll(PDO::FETCH_ASSOC);

foreach ($lowStock as $p) {
    // បង្កើតតែបើមិនទាន់មាន Notification ដូចគ្នាក្នុងថ្ងៃនេះ
    $check = $db->prepare("SELECT id FROM notifications 
        WHERE type='LOW_STOCK' AND reference_id=? AND DATE(created_at)=CURDATE()");
    $check->execute([$p['id']]);
    if (!$check->fetch()) {
        $stmt = $db->prepare("INSERT INTO notifications (type, title, message, reference_id) VALUES ('LOW_STOCK', ?, ?, ?)");
        $stmt->execute([
            "⚠️ Low Stock: {$p['name']}",
            "Only {$p['stock_qty']} items left in stock.",
            $p['id']
        ]);
    }
}

foreach ($outStock as $p) {
    $check = $db->prepare("SELECT id FROM notifications 
        WHERE type='OUT_OF_STOCK' AND reference_id=? AND DATE(created_at)=CURDATE()");
    $check->execute([$p['id']]);
    if (!$check->fetch()) {
        $stmt = $db->prepare("INSERT INTO notifications (type, title, message, reference_id) VALUES ('OUT_OF_STOCK', ?, ?, ?)");
        $stmt->execute([
            "❌ Out of Stock: {$p['name']}",
            "This product is out of stock. Please reorder.",
            $p['id']
        ]);
    }
}

// ទាញ Notifications
$filter = $_GET['filter'] ?? 'all';
$sql = "SELECT * FROM notifications WHERE 1=1";
if ($filter === 'unread') $sql .= " AND is_read = 0";
$sql .= " ORDER BY created_at DESC LIMIT 50";

$notifications = $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
$unreadCount = (int)$db->query("SELECT COUNT(*) FROM notifications WHERE is_read = 0")->fetchColumn();

echo json_encode([
    'success' => true,
    'data' => $notifications,
    'unread_count' => $unreadCount
]);