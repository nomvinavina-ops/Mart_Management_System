<?php
session_start();
header("Content-Type: application/json; charset=UTF-8");
require_once '../../config/database.php';

if (empty($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "Unauthorized"]);
    exit;
}

$db = (new Database())->getConnection();

$from = $_GET['from'] ?? date('Y-m-01');
$to   = $_GET['to']   ?? date('Y-m-d');

// ---- Summary Numbers ----
$stmt = $db->prepare("SELECT 
    COALESCE(SUM(total_amount),0) AS total_sales,
    COUNT(*) AS total_orders,
    COALESCE(SUM(tax_amount),0) AS total_tax,
    COALESCE(SUM(discount_amount),0) AS total_discount
    FROM sales WHERE DATE(created_at) BETWEEN ? AND ?");
$stmt->execute([$from, $to]);
$summary = $stmt->fetch(PDO::FETCH_ASSOC);

// ---- Daily Sales (សម្រាប់ Chart) ----
$stmt = $db->prepare("SELECT DATE(created_at) AS day, SUM(total_amount) AS total 
    FROM sales WHERE DATE(created_at) BETWEEN ? AND ? 
    GROUP BY DATE(created_at) ORDER BY day");
$stmt->execute([$from, $to]);
$daily = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ---- Top Products ----
$stmt = $db->prepare("SELECT p.name, SUM(si.qty) AS qty, SUM(si.subtotal) AS total 
    FROM sale_items si 
    JOIN products p ON si.product_id = p.id 
    JOIN sales s ON si.sale_id = s.id 
    WHERE DATE(s.created_at) BETWEEN ? AND ? 
    GROUP BY p.id ORDER BY total DESC LIMIT 10");
$stmt->execute([$from, $to]);
$topProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ---- Sales Details ----
$stmt = $db->prepare("SELECT s.id, s.invoice_no, s.created_at, s.total_amount, 
    (SELECT SUM(qty) FROM sale_items WHERE sale_id = s.id) AS items 
    FROM sales s WHERE DATE(s.created_at) BETWEEN ? AND ? 
    ORDER BY s.created_at DESC LIMIT 50");
$stmt->execute([$from, $to]);
$salesDetails = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    "success" => true,
    "summary" => [
        "total_sales" => (float)$summary['total_sales'],
        "total_orders" => (int)$summary['total_orders'],
        "total_tax" => (float)$summary['total_tax'],
        "profit" => (float)$summary['total_sales'] - (float)$summary['total_tax']
    ],
    "daily" => $daily,
    "top_products" => $topProducts,
    "sales_details" => $salesDetails
]);