<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();
verify_csrf_token();

$db = (new Database())->getConnection();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $search = $_GET['search'] ?? '';
    $sql = "SELECT * FROM suppliers WHERE 1=1";
    $params = [];
    if ($search !== '') {
        $sql .= " AND (company_name LIKE ? OR contact_person LIKE ? OR phone LIKE ?)";
        $params = ["%$search%", "%$search%", "%$search%"];
    }
    $sql .= " ORDER BY id DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    exit;
}

if ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    $errors = [];
    if (empty($data['company_name'])) $errors[] = "Company name is required";
    if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email";
    }
    if ($errors) {
        http_response_code(422);
        exit(json_encode(['success' => false, 'errors' => $errors]));
    }

    $stmt = $db->prepare("INSERT INTO suppliers 
        (company_name, contact_person, phone, email, address, status) 
        VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        sanitize($data['company_name']),
        sanitize($data['contact_person'] ?? ''),
        sanitize($data['phone'] ?? ''),
        sanitize($data['email'] ?? ''),
        sanitize($data['address'] ?? ''),
        $data['status'] ?? 'Active'
    ]);
    echo json_encode(['success' => true, 'id' => $db->lastInsertId()]);
}