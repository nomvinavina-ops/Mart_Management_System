<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();
verify_csrf_token();

if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405);
    exit(json_encode(['success' => false, 'message' => 'Method not allowed']));
}

$db = (new Database())->getConnection();
$data = json_decode(file_get_contents("php://input"), true);
$id = (int)($data['id'] ?? 0);

if (!$id || empty($data['company_name'])) {
    http_response_code(422);
    exit(json_encode(['success' => false, 'message' => 'ID and company name required']));
}

$stmt = $db->prepare("UPDATE suppliers SET 
    company_name = ?, contact_person = ?, phone = ?, email = ?, address = ?, status = ?
    WHERE id = ?");
$stmt->execute([
    sanitize($data['company_name']),
    sanitize($data['contact_person'] ?? ''),
    sanitize($data['phone'] ?? ''),
    sanitize($data['email'] ?? ''),
    sanitize($data['address'] ?? ''),
    $data['status'] ?? 'Active',
    $id
]);
echo json_encode(['success' => true, 'message' => 'Supplier updated']);