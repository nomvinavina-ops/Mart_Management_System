<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();
require_role(['admin', 'manager']);
verify_csrf_token();

$db = (new Database())->getConnection();
$data = json_decode(file_get_contents("php://input"), true);
$id = (int)($data['id'] ?? 0);

if (!$id) {
    http_response_code(400);
    exit(json_encode(['success' => false, 'message' => 'ID required']));
}

$stmt = $db->prepare("DELETE FROM suppliers WHERE id = ?");
$stmt->execute([$id]);
echo json_encode(['success' => true, 'message' => 'Supplier deleted']);