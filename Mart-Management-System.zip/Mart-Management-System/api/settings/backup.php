<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

secure_session_start();
require_login();
require_role(['admin']);

$db = (new Database())->getConnection();

$tables = ['users', 'categories', 'products', 'customers', 'suppliers', 
           'sales', 'sale_items', 'inventory_logs', 'purchase_orders', 
           'purchase_items', 'promotions', 'notifications', 'store_settings'];

$sql = "-- Mart Management System Backup\n";
$sql .= "-- Generated: " . date('Y-m-d H:i:s') . "\n\n";
$sql .= "SET FOREIGN_KEY_CHECKS=0;\n\n";

foreach ($tables as $table) {
    // Table structure
    $create = $db->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_ASSOC);
    $sql .= "\n-- Table: $table\n";
    $sql .= "DROP TABLE IF EXISTS `$table`;\n";
    $sql .= $create['Create Table'] . ";\n\n";

    // Table data
    $rows = $db->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
    if (!empty($rows)) {
        $sql .= "INSERT INTO `$table` VALUES\n";
        $values = [];
        foreach ($rows as $row) {
            $vals = array_map(fn($v) => $v === null ? 'NULL' : $db->quote((string)$v), array_values($row));
            $values[] = "(" . implode(", ", $vals) . ")";
        }
        $sql .= implode(",\n", $values) . ";\n\n";
    }
}

$sql .= "SET FOREIGN_KEY_CHECKS=1;\n";

$filename = 'backup_' . date('Ymd_His') . '.sql';
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($sql));
echo $sql;
exit;