<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();
require_role(['admin']);
verify_csrf_token();

if (empty($_FILES['backup_file'])) {
    http_response_code(400);
    exit(json_encode(['success' => false, 'message' => 'No file uploaded']));
}

$file = $_FILES['backup_file'];
if ($file['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    exit(json_encode(['success' => false, 'message' => 'Upload error']));
}

if ($file['size'] > 20 * 1024 * 1024) { // 20MB
    http_response_code(413);
    exit(json_encode(['success' => false, 'message' => 'File too large (max 20MB)']));
}

$sql = file_get_contents($file['tmp_name']);
if ($sql === false) {
    http_response_code(500);
    exit(json_encode(['success' => false, 'message' => 'Cannot read file']));
}

$db = (new Database())->getConnection();

try {
    // ប្រើ Multi-statement
    $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, true);
    $db->exec($sql);
    echo json_encode(['success' => true, 'message' => 'Database restored successfully']);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Restore failed: ' . $e->getMessage()]);
}