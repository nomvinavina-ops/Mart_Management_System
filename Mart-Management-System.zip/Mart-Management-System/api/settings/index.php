<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();
verify_csrf_token();

$db = (new Database())->getConnection();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $settings = $db->query("SELECT * FROM store_settings WHERE id = 1")->fetch(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'data' => $settings]);
    exit;
}

if ($method === 'POST') {
    require_role(['admin']);
    $data = json_decode(file_get_contents("php://input"), true);

    $stmt = $db->prepare("UPDATE store_settings SET 
        store_name = ?, store_address = ?, store_phone = ?, store_email = ?, 
        currency = ?, currency_symbol = ?, tax_rate = ?, receipt_footer = ?, 
        low_stock_threshold = ? 
        WHERE id = 1");
    $stmt->execute([
        sanitize($data['store_name'] ?? ''),
        sanitize($data['store_address'] ?? ''),
        sanitize($data['store_phone'] ?? ''),
        sanitize($data['store_email'] ?? ''),
        sanitize($data['currency'] ?? 'USD'),
        sanitize($data['currency_symbol'] ?? '$'),
        (float)($data['tax_rate'] ?? 10),
        sanitize($data['receipt_footer'] ?? ''),
        (int)($data['low_stock_threshold'] ?? 5)
    ]);

    echo json_encode(['success' => true, 'message' => 'Settings saved']);
}