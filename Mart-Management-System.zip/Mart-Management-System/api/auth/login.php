<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();

$db = (new Database())->getConnection();
$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

// សម្អាត Log ចាស់ៗ
if (random_int(1, 100) <= 5) cleanup_old_attempts($db);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Rate Limiting
check_rate_limit($db, $ip, 5, 15);

$data = json_decode(file_get_contents("php://input"), true);

if (empty($data['username']) || empty($data['password'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Username and password required']);
    exit;
}

$username = trim($data['username']);
$password = $data['password'];

try {
    $stmt = $db->prepare("SELECT id, username, password, role FROM users WHERE username = ? LIMIT 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        // ជោគជ័យ → Regenerate Session ID
        session_regenerate_id(true);

        $_SESSION['user'] = [
            'id'       => (int)$user['id'],
            'username' => $user['username'],
            'role'     => $user['role'],
            'login_at' => time()
        ];

        // បង្កើត CSRF Token ថ្មី
        generate_csrf_token();

        echo json_encode([
            'success'    => true,
            'message'    => 'Login successful',
            'role'       => $user['role'],
            'csrf_token' => $_SESSION['csrf_token']
        ]);
    } else {
        log_failed_attempt($db, $ip, $username);
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid username or password']);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error']);
}