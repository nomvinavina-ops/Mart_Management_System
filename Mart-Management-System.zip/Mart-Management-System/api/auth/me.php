<?php
declare(strict_types=1);
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();

echo json_encode([
    'success'    => true,
    'user'       => $_SESSION['user'],
    'csrf_token' => generate_csrf_token()
]);