<?php
declare(strict_types=1);
require_once __DIR__.'/../../config/bootstrap.php';
require_once __DIR__.'/../../services/ProductService.php';
requireLogin();
if($_SERVER['REQUEST_METHOD']!=='GET') jsonResponse(false,'Method not allowed.',[],405);
jsonResponse(true,'',(new ProductService($pdo))->categories());
