<?php
session_start();
header("Content-Type: application/json; charset=UTF-8");
require_once '../../config/database.php';

if (empty($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "Unauthorized"]);
    exit;
}

$db = (new Database())->getConnection();
$method = $_SERVER['REQUEST_METHOD'];

// ---------- GET: ទាញយកផលិតផលទាំងអស់ ----------
if ($method === 'GET') {
    $search = $_GET['search'] ?? '';
    $category = $_GET['category'] ?? '';

    $sql = "SELECT p.*, c.name AS category_name 
            FROM products p 
            LEFT JOIN categories c ON p.category_id = c.id 
            WHERE 1=1";
    $params = [];

    if ($search !== '') {
        $sql .= " AND (p.name LIKE ? OR p.code LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    if ($category !== '' && $category !== 'All') {
        $sql .= " AND c.name = ?";
        $params[] = $category;
    }
    $sql .= " ORDER BY p.id DESC";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(["success" => true, "data" => $products]);
    exit;
}

// ---------- POST: បង្កើតផលិតផលថ្មី ----------
if ($method === 'POST') {
    // ពិនិត្យ Role (Admin ឬ Manager ទើបបង្កើតបាន)
    if (!in_array($_SESSION['user']['role'], ['admin', 'manager'])) {
        http_response_code(403);
        echo json_encode(["success" => false, "message" => "Permission denied"]);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"), true);

    // ---------- Validation ----------
    $errors = [];
    if (empty($data['code']))          $errors[] = "Product code is required";
    if (empty($data['name']))          $errors[] = "Product name is required";
    if (empty($data['category_id']))   $errors[] = "Category is required";
    if (!isset($data['cost_price']) || $data['cost_price'] < 0)   $errors[] = "Invalid cost price";
    if (!isset($data['selling_price']) || $data['selling_price'] < 0) $errors[] = "Invalid selling price";
    if (!isset($data['stock_qty']) || $data['stock_qty'] < 0)     $errors[] = "Invalid stock quantity";

    if (!empty($errors)) {
        http_response_code(422);
        echo json_encode(["success" => false, "errors" => $errors]);
        exit;
    }

    // ពិនិត្យ Code ស្ទួន
    $check = $db->prepare("SELECT id FROM products WHERE code = ?");
    $check->execute([$data['code']]);
    if ($check->fetch()) {
        http_response_code(409);
        echo json_encode(["success" => false, "message" => "Product code already exists"]);
        exit;
    }

    try {
        $stmt = $db->prepare("INSERT INTO products 
            (code, name, category_id, cost_price, selling_price, stock_qty, image, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $data['code'],
            $data['name'],
            $data['category_id'],
            $data['cost_price'],
            $data['selling_price'],
            $data['stock_qty'],
            $data['image'] ?? 'default.png',
            $data['status'] ?? 'Available'
        ]);

        echo json_encode([
            "success" => true,
            "message" => "Product created successfully",
            "id" => $db->lastInsertId()
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["success" => false, "message" => "Database error: " . $e->getMessage()]);
    }
    exit;
}

http_response_code(405);
echo json_encode(["success" => false, "message" => "Method not allowed"]);