<?php
session_start();
header("Content-Type: application/json; charset=UTF-8");
require_once '../../config/database.php';

if (empty($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "Unauthorized"]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => "Method not allowed"]);
    exit;
}

$db = (new Database())->getConnection();
$data = json_decode(file_get_contents("php://input"), true);
$id = $data['id'] ?? 0;

if (!$id) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Product ID required"]);
    exit;
}

// Validation
$errors = [];
if (empty($data['code']))        $errors[] = "Product code is required";
if (empty($data['name']))        $errors[] = "Product name is required";
if (empty($data['category_id'])) $errors[] = "Category is required";

if (!empty($errors)) {
    http_response_code(422);
    echo json_encode(["success" => false, "errors" => $errors]);
    exit;
}

try {
    $stmt = $db->prepare("UPDATE products SET 
        code = ?, name = ?, category_id = ?, cost_price = ?, 
        selling_price = ?, stock_qty = ?, status = ? 
        WHERE id = ?");
    $stmt->execute([
        $data['code'],
        $data['name'],
        $data['category_id'],
        $data['cost_price'],
        $data['selling_price'],
        $data['stock_qty'],
        $data['status'] ?? 'Available',
        $id
    ]);

    echo json_encode(["success" => true, "message" => "Product updated successfully"]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Database error: " . $e->getMessage()]);
}