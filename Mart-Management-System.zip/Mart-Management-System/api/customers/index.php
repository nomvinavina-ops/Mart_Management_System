<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();
verify_csrf_token();

$db = (new Database())->getConnection();
$method = $_SERVER['REQUEST_METHOD'];

// ---------- GET ----------
if ($method === 'GET') {
    $search = $_GET['search'] ?? '';
    $sql = "SELECT * FROM customers WHERE 1=1";
    $params = [];

    if ($search !== '') {
        $sql .= " AND (name LIKE ? OR phone LIKE ? OR email LIKE ?)";
        $params = ["%$search%", "%$search%", "%$search%"];
    }
    $sql .= " ORDER BY id DESC";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    exit;
}

// ---------- POST ----------
if ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    // Validation
    $errors = [];
    if (empty($data['name'])) $errors[] = "Customer name is required";
    if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    if (!empty($data['phone']) && !preg_match('/^[0-9+\-\s()]{7,20}$/', $data['phone'])) {
        $errors[] = "Invalid phone number";
    }

    if ($errors) {
        http_response_code(422);
        echo json_encode(['success' => false, 'errors' => $errors]);
        exit;
    }

    try {
        $stmt = $db->prepare("INSERT INTO customers 
            (name, phone, email, address, loyalty_points, membership_level) 
            VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            sanitize($data['name']),
            sanitize($data['phone'] ?? ''),
            sanitize($data['email'] ?? ''),
            sanitize($data['address'] ?? ''),
            (int)($data['loyalty_points'] ?? 0),
            $data['membership_level'] ?? 'Bronze'
        ]);
        echo json_encode(['success' => true, 'id' => $db->lastInsertId()]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}