<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();
verify_csrf_token();

if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405);
    exit(json_encode(['success' => false, 'message' => 'Method not allowed']));
}

$db = (new Database())->getConnection();
$data = json_decode(file_get_contents("php://input"), true);
$id = (int)($data['id'] ?? 0);

if (!$id || empty($data['name'])) {
    http_response_code(422);
    exit(json_encode(['success' => false, 'message' => 'ID and name required']));
}

$stmt = $db->prepare("UPDATE customers SET 
    name = ?, phone = ?, email = ?, address = ?, membership_level = ?
    WHERE id = ?");
$stmt->execute([
    sanitize($data['name']),
    sanitize($data['phone'] ?? ''),
    sanitize($data['email'] ?? ''),
    sanitize($data['address'] ?? ''),
    $data['membership_level'] ?? 'Bronze',
    $id
]);

echo json_encode(['success' => true, 'message' => 'Customer updated']);