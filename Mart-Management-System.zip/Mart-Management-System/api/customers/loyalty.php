<?php
declare(strict_types=1);
require_once '../../config/database.php';
require_once '../../config/security.php';

header("Content-Type: application/json; charset=UTF-8");
secure_session_start();
require_login();
verify_csrf_token();

$db = (new Database())->getConnection();
$data = json_decode(file_get_contents("php://input"), true);

$customerId = (int)($data['customer_id'] ?? 0);
$points     = (int)($data['points'] ?? 0);
$action     = $data['action'] ?? 'add'; // add | redeem

if (!$customerId || $points <= 0) {
    http_response_code(422);
    exit(json_encode(['success' => false, 'message' => 'Invalid parameters']));
}

// ទាញទិន្នន័យបច្ចុប្បន្ន
$stmt = $db->prepare("SELECT loyalty_points FROM customers WHERE id = ?");
$stmt->execute([$customerId]);
$current = (int)$stmt->fetchColumn();

if ($action === 'redeem' && $current < $points) {
    http_response_code(400);
    exit(json_encode(['success' => false, 'message' => 'Insufficient loyalty points']));
}

$newPoints = $action === 'add' ? $current + $points : $current - $points;

// កំណត់ Membership Level ដោយស្វ័យប្រវត្តិ
$level = 'Bronze';
if ($newPoints >= 5000) $level = 'Platinum';
elseif ($newPoints >= 2000) $level = 'Gold';
elseif ($newPoints >= 500) $level = 'Silver';

$stmt = $db->prepare("UPDATE customers SET loyalty_points = ?, membership_level = ? WHERE id = ?");
$stmt->execute([$newPoints, $level, $customerId]);

echo json_encode([
    'success' => true,
    'points'  => $newPoints,
    'level'   => $level
]);