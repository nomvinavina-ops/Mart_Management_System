/* ============================================
   assets/js/sidebar.js
   ============================================ */

(function () {
    'use strict';

    window.csrfToken = localStorage.getItem('csrf_token') || '';

    window.apiFetch = async function (url, options = {}) {
        const headers = {
            'Content-Type': 'application/json',
            ...(options.headers || {})
        };
        if (window.csrfToken) headers['X-CSRF-Token'] = window.csrfToken;

        const res = await fetch(url, { ...options, headers, credentials: 'same-origin' });
        const data = await res.json();

        if (data.csrf_token) {
            window.csrfToken = data.csrf_token;
            localStorage.setItem('csrf_token', window.csrfToken);
        }
        if (res.status === 401) {
            localStorage.removeItem('csrf_token');
            window.location.href = 'login.html';
            return { success: false };
        }
        return data;
    };

    window.logout = async function () {
        if (!confirm('តើអ្នកពិតជាចង់ចាកចេញមែនទេ?')) return;
        try {
            await fetch('../../api/auth/logout.php', {
                method: 'POST',
                headers: { 'X-CSRF-Token': window.csrfToken },
                credentials: 'same-origin'
            });
        } catch (e) { console.error(e); }
        localStorage.removeItem('csrf_token');
        window.location.href = 'login.html';
    };

    // ============ Load Sidebar ============
    document.addEventListener('DOMContentLoaded', async () => {
        const container = document.getElementById('sidebar-container');
        if (!container) return;

        // ✅ បង្កើត Path ដោយផ្ទាល់ពី Root
        const basePath = '/WebQatar/Mart-Management-System';
        const sidebarUrl = basePath + '/assets/sidebar.html';

        console.log('🔄 Loading sidebar from:', sidebarUrl);

        try {
            const res = await fetch(sidebarUrl);
            if (!res.ok) {
                throw new Error('HTTP ' + res.status + ' — ' + sidebarUrl);
            }

            const html = await res.text();
            container.innerHTML = html;

            const currentPage = document.body.dataset.page || 'dashboard';
            const activeLink = container.querySelector(`[data-page="${currentPage}"]`);
            if (activeLink) activeLink.classList.add('active');

            console.log('✅ Sidebar loaded successfully');

        } catch (err) {
            console.error('❌ Sidebar error:', err);
            container.innerHTML = `
                <div style="padding:20px; color:white; background:#dc3545; font-size:12px;">
                    <strong>❌ Sidebar Error</strong><br>
                    ${err.message}
                </div>
            `;
        }
    });

})();