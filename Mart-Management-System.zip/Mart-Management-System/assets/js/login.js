document.addEventListener('DOMContentLoaded',()=>{
  const form=document.getElementById('loginForm');
  if(!form)return;
  form.addEventListener('submit',async e=>{
    e.preventDefault();
    const btn=form.querySelector('button[type="submit"]');
    const login=document.getElementById('username').value.trim();
    const password=document.getElementById('password').value;
    btn.disabled=true;
    try{
      await fetch('../api/auth/login.php',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({login,password})})
        .then(async r=>{const d=await r.json();if(!r.ok||!d.success)throw new Error(d.message||'Login failed');return d;});
      location.href='dashboard.html';
    }catch(err){alert(err.message);}finally{btn.disabled=false;}
  });
});
