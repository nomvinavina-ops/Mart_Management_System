<?php
declare(strict_types=1);

final class InventoryService {
    public function __construct(private PDO $db) {}

    public function all(): array {
        $sql = "SELECT p.product_id,p.product_code,p.product_name,c.category_name,
                       i.quantity,p.expiry_date,
                       CASE WHEN i.quantity <= 5 THEN 'Low' ELSE 'Available' END AS status
                FROM products p
                LEFT JOIN categories c ON c.category_id=p.category_id
                JOIN inventory i ON i.product_id=p.product_id
                ORDER BY i.quantity ASC, p.product_name";
        return $this->db->query($sql)->fetchAll();
    }
}
