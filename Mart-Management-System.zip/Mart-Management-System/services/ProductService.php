<?php
declare(strict_types=1);

final class ProductService {
    public function __construct(private PDO $db) {}

    public function all(string $search = '', int $categoryId = 0): array {
        $sql = "SELECT p.product_id,p.product_code,p.product_name,p.category_id,c.category_name,
                       p.brand,p.unit,p.cost_price,p.selling_price,p.expiry_date,
                       COALESCE(i.quantity,0) AS quantity,
                       CASE WHEN COALESCE(i.quantity,0)=0 THEN 'Out of Stock'
                            WHEN COALESCE(i.quantity,0)<=5 THEN 'Low'
                            ELSE 'Available' END AS status
                FROM products p
                LEFT JOIN categories c ON c.category_id=p.category_id
                LEFT JOIN inventory i ON i.product_id=p.product_id
                WHERE (:search='' OR p.product_name LIKE :like1 OR p.product_code LIKE :like2)
                  AND (:category=0 OR p.category_id=:category)
                ORDER BY p.product_id DESC";
        $stmt=$this->db->prepare($sql);
        $like="%{$search}%";
        $stmt->execute(['search'=>$search,'like1'=>$like,'like2'=>$like,'category'=>$categoryId]);
        return $stmt->fetchAll();
    }

    public function categories(): array {
        return $this->db->query('SELECT category_id,category_name FROM categories ORDER BY category_name')->fetchAll();
    }

    public function create(array $d): int {
        $this->db->beginTransaction();
        try {
            $stmt=$this->db->prepare('INSERT INTO products(product_code,product_name,category_id,brand,unit,cost_price,selling_price,expiry_date) VALUES(?,?,?,?,?,?,?,?)');
            $stmt->execute([
                trim((string)$d['product_code']), trim((string)$d['product_name']), !empty($d['category_id'])?(int)$d['category_id']:null,
                trim((string)($d['brand']??'')), trim((string)($d['unit']??'pcs')),
                (float)$d['cost_price'],(float)$d['selling_price'],!empty($d['expiry_date'])?$d['expiry_date']:null
            ]);
            $id=(int)$this->db->lastInsertId();
            $stock=max(0,(int)($d['stock']??0));
            $this->db->prepare('INSERT INTO inventory(product_id,quantity,stock_type) VALUES(?, ?, ?)')->execute([$id,$stock,$stock<=5?'Low':'Available']);
            $this->db->commit();
            return $id;
        } catch(Throwable $e){$this->db->rollBack();throw $e;}
    }

    public function update(int $id,array $d): void {
        $this->db->beginTransaction();
        try {
            $stmt=$this->db->prepare('UPDATE products SET product_code=?,product_name=?,category_id=?,brand=?,unit=?,cost_price=?,selling_price=?,expiry_date=? WHERE product_id=?');
            $stmt->execute([trim((string)$d['product_code']),trim((string)$d['product_name']),!empty($d['category_id'])?(int)$d['category_id']:null,trim((string)($d['brand']??'')),trim((string)($d['unit']??'pcs')),(float)$d['cost_price'],(float)$d['selling_price'],!empty($d['expiry_date'])?$d['expiry_date']:null,$id]);
            if(array_key_exists('stock',$d)){
                $q=max(0,(int)$d['stock']);
                $this->db->prepare('INSERT INTO inventory(product_id,quantity,stock_type) VALUES(?,?,?) ON DUPLICATE KEY UPDATE quantity=VALUES(quantity),stock_type=VALUES(stock_type)')->execute([$id,$q,$q<=5?'Low':'Available']);
            }
            $this->db->commit();
        }catch(Throwable $e){$this->db->rollBack();throw $e;}
    }

    public function delete(int $id): void {
        $stmt=$this->db->prepare('DELETE FROM products WHERE product_id=?');
        $stmt->execute([$id]);
        if($stmt->rowCount()===0) throw new InvalidArgumentException('Product not found.');
    }
}
