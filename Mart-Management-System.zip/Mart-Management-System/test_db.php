<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
echo "<h2>🔍 Database Test — mart</h2>";

try {
    $pdo = new PDO("mysql:host=localhost;port=3306;dbname=mart;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<p>✅ Connected to: <strong>mart</strong></p>";

    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "<p>📋 Tables found: <strong>" . count($tables) . "</strong></p>";
    echo "<ul>";
    foreach ($tables as $t) echo "<li>$t</li>";
    echo "</ul>";

    // ពិនិត្យ Table users
    if (in_array('users', $tables)) {
        $users = $pdo->query("SELECT id, username, role FROM users")->fetchAll(PDO::FETCH_ASSOC);
        echo "<p>👥 Users: <strong>" . count($users) . "</strong></p>";
        echo "<ul>";
        foreach ($users as $u) echo "<li>ID: {$u['id']} | Username: <strong>{$u['username']}</strong> | Role: {$u['role']}</li>";
        echo "</ul>";
    } else {
        echo "<p style='color:red;'>❌ Table users NOT FOUND — Run the SQL above!</p>";
    }

    // ពិនិត្យ Products
    $count = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    echo "<p>📦 Products: <strong>$count</strong></p>";

} catch (PDOException $e) {
    echo "<p>❌ Error: " . $e->getMessage() . "</p>";
}